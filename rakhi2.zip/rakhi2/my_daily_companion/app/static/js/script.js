document.addEventListener('DOMContentLoaded', function () {
    console.log('JavaScript is loaded and working!');
});
