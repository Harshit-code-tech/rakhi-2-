document.addEventListener('DOMContentLoaded', function () {
    console.log("App is running.");
    // Add your JavaScript code here.

});
