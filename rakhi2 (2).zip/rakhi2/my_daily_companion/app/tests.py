from django.test import TestCase


class YourTestClass(TestCase):
    def test_something(self):
        self.assertEqual(1 + 1, 2)
